import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { loginUser, registerUser, fetchProfile } from "../services/authService";
import { getTokenExpiryMs, isTokenExpired } from "../utils/jwt";
import { useToast } from "./ToastContext";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem("tf_token"));
  const [initializing, setInitializing] = useState(true);
  const logoutTimerRef = useRef(null);
  const { toast } = useToast();

  const clearSession = useCallback((message) => {
    localStorage.removeItem("tf_token");
    setToken(null);
    setUser(null);
    if (logoutTimerRef.current) {
      clearTimeout(logoutTimerRef.current);
      logoutTimerRef.current = null;
    }
    if (message) toast?.info(message);
  }, [toast]);

  const scheduleAutoLogout = useCallback(
    (jwt) => {
      if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
      const expiryMs = getTokenExpiryMs(jwt);
      if (!expiryMs) return;
      const msRemaining = expiryMs - Date.now();
      if (msRemaining <= 0) {
        clearSession("Your session has expired. Please log in again.");
        return;
      }
      logoutTimerRef.current = setTimeout(() => {
        clearSession("Your session has expired. Please log in again.");
      }, msRemaining);
    },
    [clearSession]
  );

  // Bootstrap session on load
  useEffect(() => {
    const init = async () => {
      const storedToken = localStorage.getItem("tf_token");
      if (!storedToken || isTokenExpired(storedToken)) {
        if (storedToken) localStorage.removeItem("tf_token");
        setInitializing(false);
        return;
      }
      try {
        const data = await fetchProfile();
        setUser(data.user);
        setToken(storedToken);
        scheduleAutoLogout(storedToken);
      } catch (err) {
        localStorage.removeItem("tf_token");
      } finally {
        setInitializing(false);
      }
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Listen for 401s from the API layer (expired/invalid token) -> auto logout
  useEffect(() => {
    const handler = () => {
      if (localStorage.getItem("tf_token")) {
        clearSession("Your session has expired. Please log in again.");
      }
    };
    window.addEventListener("tf-unauthorized", handler);
    return () => window.removeEventListener("tf-unauthorized", handler);
  }, [clearSession]);

  const login = async (credentials) => {
    const data = await loginUser(credentials);
    localStorage.setItem("tf_token", data.token);
    setToken(data.token);
    setUser(data.user);
    scheduleAutoLogout(data.token);
    return data;
  };

  const register = async (payload) => {
    const data = await registerUser(payload);
    localStorage.setItem("tf_token", data.token);
    setToken(data.token);
    setUser(data.user);
    scheduleAutoLogout(data.token);
    return data;
  };

  const logout = () => {
    clearSession();
  };

  const updateUserInContext = (updatedUser) => {
    setUser((prev) => ({ ...prev, ...updatedUser }));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token && !!user,
        initializing,
        login,
        register,
        logout,
        updateUserInContext,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
