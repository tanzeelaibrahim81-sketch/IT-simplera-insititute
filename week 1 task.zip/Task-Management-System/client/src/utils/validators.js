export const isValidEmail = (value) => /^\S+@\S+\.\S+$/.test(value);

export const validateRegisterForm = ({ name, email, password, confirmPassword }) => {
  const errors = {};
  if (!name || !name.trim()) errors.name = "Name is required";
  if (!email) errors.email = "Email is required";
  else if (!isValidEmail(email)) errors.email = "Enter a valid email address";
  if (!password) errors.password = "Password is required";
  else if (password.length < 6) errors.password = "Password must be at least 6 characters";
  if (confirmPassword !== undefined) {
    if (!confirmPassword) errors.confirmPassword = "Please confirm your password";
    else if (confirmPassword !== password) errors.confirmPassword = "Passwords do not match";
  }
  return errors;
};

export const validateLoginForm = ({ email, password }) => {
  const errors = {};
  if (!email) errors.email = "Email is required";
  else if (!isValidEmail(email)) errors.email = "Enter a valid email address";
  if (!password) errors.password = "Password is required";
  return errors;
};

export const validateTaskForm = ({ title, dueDate }) => {
  const errors = {};
  if (!title || !title.trim()) errors.title = "Title is required";
  else if (title.length > 120) errors.title = "Title must be under 120 characters";
  if (!dueDate) errors.dueDate = "Due date is required";
  return errors;
};

export const validatePasswordForm = ({ currentPassword, newPassword, confirmNewPassword }) => {
  const errors = {};
  if (!currentPassword) errors.currentPassword = "Current password is required";
  if (!newPassword) errors.newPassword = "New password is required";
  else if (newPassword.length < 6) errors.newPassword = "New password must be at least 6 characters";
  if (confirmNewPassword !== newPassword) errors.confirmNewPassword = "Passwords do not match";
  return errors;
};
