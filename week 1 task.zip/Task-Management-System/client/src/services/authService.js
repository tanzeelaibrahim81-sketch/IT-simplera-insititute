import api from "./api";

export const registerUser = (payload) => api.post("/auth/register", payload).then((res) => res.data);

export const loginUser = (payload) => api.post("/auth/login", payload).then((res) => res.data);

export const fetchProfile = () => api.get("/users/me").then((res) => res.data);

export const updateProfile = (payload) => api.put("/users/me", payload).then((res) => res.data);

export const changePassword = (payload) => api.put("/users/change-password", payload).then((res) => res.data);
