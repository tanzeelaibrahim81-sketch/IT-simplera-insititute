import React from "react";
import { useNavigate } from "react-router-dom";
import { StatusBadge, PriorityBadge } from "./Badge";
import { InlineLoader } from "./Loader";

const formatDate = (value) => {
  if (!value) return "—";
  const d = new Date(value);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
};

const isOverdue = (dueDate, status) => {
  if (status === "Completed") return false;
  return new Date(dueDate).getTime() < Date.now();
};

const TaskTable = ({
  tasks,
  loading,
  filters,
  onFilterChange,
  pagination,
  onPageChange,
  onDeleteClick,
}) => {
  const navigate = useNavigate();

  return (
    <div className="table-wrap">
      <div className="table-toolbar">
        <div className="search-box">
          <span className="icon">⌕</span>
          <input
            type="text"
            className="input"
            placeholder="Search tasks by title or description…"
            value={filters.search}
            onChange={(e) => onFilterChange({ search: e.target.value })}
          />
        </div>

        <select
          className="select"
          style={{ width: "auto" }}
          value={filters.status}
          onChange={(e) => onFilterChange({ status: e.target.value })}
        >
          <option value="All">All statuses</option>
          <option value="To Do">To Do</option>
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
        </select>

        <select
          className="select"
          style={{ width: "auto" }}
          value={filters.priority}
          onChange={(e) => onFilterChange({ priority: e.target.value })}
        >
          <option value="All">All priorities</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      </div>

      {loading ? (
        <div className="empty-state">
          <InlineLoader />
          <p style={{ marginTop: "10px" }}>Loading tasks…</p>
        </div>
      ) : tasks.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">◈</div>
          <h3>No tasks found</h3>
          <p>Try adjusting your search or filters, or create a new task.</p>
        </div>
      ) : (
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Created</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task) => (
                <tr key={task._id}>
                  <td>
                    <div className="task-title-cell">{task.title}</div>
                    {task.description && <div className="task-desc-cell">{task.description}</div>}
                  </td>
                  <td>
                    <PriorityBadge priority={task.priority} />
                  </td>
                  <td>
                    <StatusBadge status={task.status} />
                  </td>
                  <td className="mono" style={{ color: isOverdue(task.dueDate, task.status) ? "var(--danger)" : "inherit" }}>
                    {formatDate(task.dueDate)}
                  </td>
                  <td className="mono text-muted">{formatDate(task.createdAt)}</td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() => navigate(`/tasks/${task._id}/edit`)}
                      >
                        Edit
                      </button>
                      <button className="btn btn-danger btn-sm" onClick={() => onDeleteClick(task)}>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {!loading && tasks.length > 0 && (
        <div className="pagination">
          <span className="page-info mono">
            Page {pagination.page} of {pagination.totalPages} · {pagination.total} total
          </span>
          <div className="page-btns">
            <button
              className="btn btn-secondary btn-sm"
              disabled={pagination.page <= 1}
              onClick={() => onPageChange(pagination.page - 1)}
            >
              ← Prev
            </button>
            <button
              className="btn btn-secondary btn-sm"
              disabled={pagination.page >= pagination.totalPages}
              onClick={() => onPageChange(pagination.page + 1)}
            >
              Next →
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskTable;
