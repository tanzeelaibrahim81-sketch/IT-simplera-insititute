import React from "react";

const statusClassMap = {
  "To Do": "badge-status-todo",
  "In Progress": "badge-status-inprogress",
  Completed: "badge-status-completed",
};

const priorityClassMap = {
  Low: "badge-priority-low",
  Medium: "badge-priority-medium",
  High: "badge-priority-high",
};

export const StatusBadge = ({ status }) => (
  <span className={`badge ${statusClassMap[status] || "badge-status-todo"}`}>{status}</span>
);

export const PriorityBadge = ({ priority }) => (
  <span className={`badge ${priorityClassMap[priority] || "badge-priority-medium"}`}>{priority}</span>
);
