import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

const Navbar = ({ onMenuClick }) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .slice(0, 2)
        .join("")
        .toUpperCase()
    : "?";

  return (
    <header className="navbar">
      <div className="nav-left">
        <button className="hamburger" onClick={onMenuClick} aria-label="Open menu">
          ☰
        </button>
      </div>

      <div className="nav-right">
        <button className="theme-toggle" onClick={toggleTheme} aria-label="Toggle theme" title="Toggle theme">
          {theme === "dark" ? "☀" : "☾"}
        </button>

        <div className="user-menu" ref={menuRef} onClick={() => setMenuOpen((o) => !o)}>
          <span className="avatar" style={{ background: user?.avatarColor || "#f2994a" }}>
            {initials}
          </span>
          <span className="user-menu-name">{user?.name?.split(" ")[0] || "Account"}</span>

          {menuOpen && (
            <div className="user-dropdown">
              <a onClick={() => navigate("/profile")}>My Profile</a>
              <button onClick={handleLogout}>Log Out</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
