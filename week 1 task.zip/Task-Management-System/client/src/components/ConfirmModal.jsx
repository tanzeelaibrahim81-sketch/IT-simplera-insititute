import React from "react";

const ConfirmModal = ({ title, message, confirmLabel = "Confirm", onConfirm, onCancel, loading }) => {
  return (
    <div className="modal-backdrop" onClick={onCancel}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <h3 style={{ fontSize: "17px", marginBottom: "8px" }}>{title}</h3>
        <p className="text-muted" style={{ fontSize: "14px" }}>
          {message}
        </p>
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onCancel} disabled={loading}>
            Cancel
          </button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
            {loading ? "Please wait…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
