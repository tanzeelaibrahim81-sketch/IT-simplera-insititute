import React from "react";

export const PageLoader = () => (
  <div className="page-loading">
    <div className="spark-loader" role="status" aria-label="Loading" />
  </div>
);

export const InlineLoader = () => <span className="spark-loader inline" role="status" aria-label="Loading" />;

export const OverlayLoader = () => (
  <div className="loader-overlay">
    <div className="spark-loader" role="status" aria-label="Loading" />
  </div>
);
