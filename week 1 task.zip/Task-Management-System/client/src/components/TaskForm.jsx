import React, { useState } from "react";
import { validateTaskForm } from "../utils/validators";
import { InlineLoader } from "./Loader";

const toDateInputValue = (value) => {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
};

const TaskForm = ({ initialValues, onSubmit, submitLabel = "Save Task", onCancel }) => {
  const [form, setForm] = useState({
    title: initialValues?.title || "",
    description: initialValues?.description || "",
    priority: initialValues?.priority || "Medium",
    status: initialValues?.status || "To Do",
    dueDate: toDateInputValue(initialValues?.dueDate) || "",
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setErrors((err) => ({ ...err, [e.target.name]: undefined }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validation = validateTaskForm(form);
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;

    setSubmitting(true);
    try {
      await onSubmit(form);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="card">
      <div className="field">
        <label htmlFor="title">Title</label>
        <input
          id="title"
          name="title"
          type="text"
          className={`input ${errors.title ? "has-error" : ""}`}
          placeholder="e.g. Prepare sprint retro notes"
          value={form.title}
          onChange={handleChange}
        />
        {errors.title && <div className="field-error">{errors.title}</div>}
      </div>

      <div className="field">
        <label htmlFor="description">Description</label>
        <textarea
          id="description"
          name="description"
          className="textarea"
          placeholder="Add any helpful details…"
          value={form.description}
          onChange={handleChange}
        />
      </div>

      <div className="field-row">
        <div className="field">
          <label htmlFor="priority">Priority</label>
          <select id="priority" name="priority" className="select" value={form.priority} onChange={handleChange}>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>

        <div className="field">
          <label htmlFor="status">Status</label>
          <select id="status" name="status" className="select" value={form.status} onChange={handleChange}>
            <option value="To Do">To Do</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
      </div>

      <div className="field">
        <label htmlFor="dueDate">Due date</label>
        <input
          id="dueDate"
          name="dueDate"
          type="date"
          className={`input ${errors.dueDate ? "has-error" : ""}`}
          value={form.dueDate}
          onChange={handleChange}
        />
        {errors.dueDate && <div className="field-error">{errors.dueDate}</div>}
      </div>

      <div className="flex gap-12" style={{ marginTop: "24px" }}>
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          {submitting ? <InlineLoader /> : submitLabel}
        </button>
        <button type="button" className="btn btn-secondary" onClick={onCancel} disabled={submitting}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default TaskForm;
