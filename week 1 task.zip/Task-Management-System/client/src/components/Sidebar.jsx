import React from "react";
import { NavLink } from "react-router-dom";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: "◈" },
  { to: "/tasks/new", label: "Create Task", icon: "＋" },
  { to: "/profile", label: "Profile", icon: "◐" },
];

const Sidebar = ({ open, onClose }) => {
  return (
    <>
      <div className={`sidebar-backdrop ${open ? "open" : ""}`} onClick={onClose} />
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-brand">
          <span className="auth-brand-mark">TF</span>
          TaskForge
        </div>

        <nav style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <span className="nav-icon">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          TASKFORGE v1.0
          <br />
          ITSimplera Internship
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
