import React from "react";
import { useNavigate } from "react-router-dom";
import TaskForm from "../components/TaskForm";
import { createTask } from "../services/taskService";
import { useToast } from "../context/ToastContext";

const CreateTask = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (values) => {
    try {
      await createTask(values);
      toast.success("Task created");
      navigate("/dashboard");
    } catch (err) {
      toast.error(err?.response?.data?.message || "Couldn't create task");
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-eyebrow">New Task</span>
          <h1 className="page-title">Create a task</h1>
          <p className="page-subtitle">Give it a clear title so future-you knows exactly what to do.</p>
        </div>
      </div>

      <div style={{ maxWidth: "560px" }}>
        <TaskForm onSubmit={handleSubmit} submitLabel="Create Task" onCancel={() => navigate("/dashboard")} />
      </div>
    </div>
  );
};

export default CreateTask;
