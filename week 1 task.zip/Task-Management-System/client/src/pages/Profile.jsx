import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { updateProfile as updateProfileApi, changePassword as changePasswordApi } from "../services/authService";
import { validatePasswordForm } from "../utils/validators";
import { InlineLoader } from "../components/Loader";

const Profile = () => {
  const { user, updateUserInContext } = useAuth();
  const { toast } = useToast();

  const [profileForm, setProfileForm] = useState({ name: user?.name || "", bio: user?.bio || "" });
  const [profileErrors, setProfileErrors] = useState({});
  const [savingProfile, setSavingProfile] = useState(false);

  const [pwForm, setPwForm] = useState({ currentPassword: "", newPassword: "", confirmNewPassword: "" });
  const [pwErrors, setPwErrors] = useState({});
  const [savingPw, setSavingPw] = useState(false);

  const initials = user?.name
    ? user.name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  const handleProfileChange = (e) => {
    setProfileForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setProfileErrors((err) => ({ ...err, [e.target.name]: undefined }));
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    if (!profileForm.name.trim()) {
      setProfileErrors({ name: "Name cannot be empty" });
      return;
    }
    setSavingProfile(true);
    try {
      const data = await updateProfileApi(profileForm);
      updateUserInContext(data.user);
      toast.success("Profile updated");
    } catch (err) {
      toast.error(err?.response?.data?.message || "Couldn't update profile");
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePwChange = (e) => {
    setPwForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setPwErrors((err) => ({ ...err, [e.target.name]: undefined }));
  };

  const handlePwSubmit = async (e) => {
    e.preventDefault();
    const validation = validatePasswordForm(pwForm);
    setPwErrors(validation);
    if (Object.keys(validation).length > 0) return;

    setSavingPw(true);
    try {
      await changePasswordApi({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      toast.success("Password changed successfully");
      setPwForm({ currentPassword: "", newPassword: "", confirmNewPassword: "" });
    } catch (err) {
      toast.error(err?.response?.data?.message || "Couldn't change password");
    } finally {
      setSavingPw(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-eyebrow">Account</span>
          <h1 className="page-title">Your profile</h1>
          <p className="page-subtitle">Manage your personal details and account security.</p>
        </div>
      </div>

      <div className="flex items-center gap-12" style={{ marginBottom: "26px" }}>
        <span
          className="avatar"
          style={{ width: "56px", height: "56px", fontSize: "20px", background: user?.avatarColor || "#f2994a" }}
        >
          {initials}
        </span>
        <div>
          <div style={{ fontWeight: 700, fontSize: "16px" }}>{user?.name}</div>
          <div className="text-muted" style={{ fontSize: "13.5px" }}>{user?.email}</div>
        </div>
      </div>

      <div className="two-col">
        <form className="card" onSubmit={handleProfileSubmit} noValidate>
          <div className="section-title">Profile details</div>

          <div className="field">
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              className={`input ${profileErrors.name ? "has-error" : ""}`}
              value={profileForm.name}
              onChange={handleProfileChange}
            />
            {profileErrors.name && <div className="field-error">{profileErrors.name}</div>}
          </div>

          <div className="field">
            <label htmlFor="bio">Bio</label>
            <textarea
              id="bio"
              name="bio"
              className="textarea"
              placeholder="A short line about what you're working on…"
              value={profileForm.bio}
              onChange={handleProfileChange}
              maxLength={300}
            />
          </div>

          <div className="field">
            <label>Email address</label>
            <input className="input" value={user?.email || ""} disabled style={{ opacity: 0.6 }} />
          </div>

          <button type="submit" className="btn btn-primary" disabled={savingProfile}>
            {savingProfile ? <InlineLoader /> : "Save Changes"}
          </button>
        </form>

        <form className="card" onSubmit={handlePwSubmit} noValidate>
          <div className="section-title">Change password</div>

          <div className="field">
            <label htmlFor="currentPassword">Current password</label>
            <input
              id="currentPassword"
              name="currentPassword"
              type="password"
              className={`input ${pwErrors.currentPassword ? "has-error" : ""}`}
              value={pwForm.currentPassword}
              onChange={handlePwChange}
              autoComplete="current-password"
            />
            {pwErrors.currentPassword && <div className="field-error">{pwErrors.currentPassword}</div>}
          </div>

          <div className="field">
            <label htmlFor="newPassword">New password</label>
            <input
              id="newPassword"
              name="newPassword"
              type="password"
              className={`input ${pwErrors.newPassword ? "has-error" : ""}`}
              value={pwForm.newPassword}
              onChange={handlePwChange}
              autoComplete="new-password"
            />
            {pwErrors.newPassword && <div className="field-error">{pwErrors.newPassword}</div>}
          </div>

          <div className="field">
            <label htmlFor="confirmNewPassword">Confirm new password</label>
            <input
              id="confirmNewPassword"
              name="confirmNewPassword"
              type="password"
              className={`input ${pwErrors.confirmNewPassword ? "has-error" : ""}`}
              value={pwForm.confirmNewPassword}
              onChange={handlePwChange}
              autoComplete="new-password"
            />
            {pwErrors.confirmNewPassword && <div className="field-error">{pwErrors.confirmNewPassword}</div>}
          </div>

          <button type="submit" className="btn btn-primary" disabled={savingPw}>
            {savingPw ? <InlineLoader /> : "Update Password"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
