import React, { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getTasks, getTaskStats, deleteTask } from "../services/taskService";
import TaskTable from "../components/TaskTable";
import ConfirmModal from "../components/ConfirmModal";
import { useToast } from "../context/ToastContext";
import { useAuth } from "../context/AuthContext";

const STATUS_COLORS = {
  "To Do": "var(--info)",
  "In Progress": "var(--accent)",
  Completed: "var(--success)",
};

const PRIORITY_COLORS = {
  Low: "var(--success)",
  Medium: "var(--accent)",
  High: "var(--danger)",
};

const MiniBarChart = ({ data, colors }) => {
  const max = Math.max(...Object.values(data), 1);
  return (
    <div>
      {Object.entries(data).map(([label, count]) => (
        <div className="mini-bar-row" key={label}>
          <span className="mini-bar-label">{label}</span>
          <div className="mini-bar-track">
            <div
              className="mini-bar-fill"
              style={{ width: `${(count / max) * 100}%`, background: colors[label] || "var(--accent)" }}
            />
          </div>
          <span className="mini-bar-count">{count}</span>
        </div>
      ))}
    </div>
  );
};

const Dashboard = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [stats, setStats] = useState(null);
  const [statsLoading, setStatsLoading] = useState(true);

  const [tasks, setTasks] = useState([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [filters, setFilters] = useState({ search: "", status: "All", priority: "All" });
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const loadStats = useCallback(async () => {
    setStatsLoading(true);
    try {
      const data = await getTaskStats();
      setStats(data.stats);
    } catch (err) {
      toast.error("Couldn't load dashboard statistics.");
    } finally {
      setStatsLoading(false);
    }
  }, [toast]);

  const loadTasks = useCallback(
    async (page = 1) => {
      setTasksLoading(true);
      try {
        const data = await getTasks({
          search: filters.search || undefined,
          status: filters.status,
          priority: filters.priority,
          page,
          limit: 8,
        });
        setTasks(data.tasks);
        setPagination(data.pagination);
      } catch (err) {
        toast.error("Couldn't load tasks.");
      } finally {
        setTasksLoading(false);
      }
    },
    [filters, toast]
  );

  useEffect(() => {
    loadStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Debounce search + refetch on filter change
  useEffect(() => {
    const timer = setTimeout(() => {
      loadTasks(1);
    }, 350);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  const handleFilterChange = (patch) => setFilters((f) => ({ ...f, ...patch }));

  const handleConfirmDelete = async () => {
    if (!taskToDelete) return;
    setDeleting(true);
    try {
      await deleteTask(taskToDelete._id);
      toast.success("Task deleted");
      setTaskToDelete(null);
      loadTasks(pagination.page);
      loadStats();
    } catch (err) {
      toast.error(err?.response?.data?.message || "Couldn't delete task");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-eyebrow">Dashboard</span>
          <h1 className="page-title">Welcome back, {user?.name?.split(" ")[0]}</h1>
          <p className="page-subtitle">Here's where things stand across your tasks.</p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate("/tasks/new")}>
          ＋ New Task
        </button>
      </div>

      <div className="stat-grid">
        <div className="stat-card" style={{ "--stat-color": "var(--accent)" }}>
          <div className="stat-label">Total Tasks</div>
          <div className="stat-value">{statsLoading ? "—" : stats?.total ?? 0}</div>
          <div className="stat-sub">Across all statuses</div>
        </div>
        <div className="stat-card" style={{ "--stat-color": "var(--info)" }}>
          <div className="stat-label">In Progress</div>
          <div className="stat-value">{statsLoading ? "—" : stats?.byStatus?.["In Progress"] ?? 0}</div>
          <div className="stat-sub">Currently active</div>
        </div>
        <div className="stat-card" style={{ "--stat-color": "var(--success)" }}>
          <div className="stat-label">Completed</div>
          <div className="stat-value">{statsLoading ? "—" : stats?.byStatus?.Completed ?? 0}</div>
          <div className="stat-sub">Nice work</div>
        </div>
        <div className="stat-card" style={{ "--stat-color": "var(--danger)" }}>
          <div className="stat-label">Overdue</div>
          <div className="stat-value">{statsLoading ? "—" : stats?.overdue ?? 0}</div>
          <div className="stat-sub">Needs attention</div>
        </div>
      </div>

      <div className="two-col mt-24" style={{ marginBottom: "24px" }}>
        <div className="card">
          <div className="section-title">By Status</div>
          {!statsLoading && stats && <MiniBarChart data={stats.byStatus} colors={STATUS_COLORS} />}
        </div>
        <div className="card">
          <div className="section-title">By Priority</div>
          {!statsLoading && stats && <MiniBarChart data={stats.byPriority} colors={PRIORITY_COLORS} />}
        </div>
      </div>

      <div className="section-title">Your Tasks</div>
      <TaskTable
        tasks={tasks}
        loading={tasksLoading}
        filters={filters}
        onFilterChange={handleFilterChange}
        pagination={pagination}
        onPageChange={loadTasks}
        onDeleteClick={setTaskToDelete}
      />

      {taskToDelete && (
        <ConfirmModal
          title="Delete this task?"
          message={`"${taskToDelete.title}" will be permanently removed. This can't be undone.`}
          confirmLabel="Delete Task"
          onConfirm={handleConfirmDelete}
          onCancel={() => setTaskToDelete(null)}
          loading={deleting}
        />
      )}
    </div>
  );
};

export default Dashboard;
