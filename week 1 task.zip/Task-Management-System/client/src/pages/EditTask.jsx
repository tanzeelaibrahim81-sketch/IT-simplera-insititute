import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import TaskForm from "../components/TaskForm";
import { getTask, updateTask } from "../services/taskService";
import { useToast } from "../context/ToastContext";
import { PageLoader } from "../components/Loader";

const EditTask = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await getTask(id);
        setTask(data.task);
      } catch (err) {
        setNotFound(true);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const handleSubmit = async (values) => {
    try {
      await updateTask(id, values);
      toast.success("Task updated");
      navigate("/dashboard");
    } catch (err) {
      toast.error(err?.response?.data?.message || "Couldn't update task");
    }
  };

  if (loading) return <PageLoader />;

  if (notFound || !task) {
    return (
      <div className="empty-state">
        <div className="empty-icon">⚠</div>
        <h3>Task not found</h3>
        <p>It may have been deleted already.</p>
        <button className="btn btn-secondary mt-24" onClick={() => navigate("/dashboard")}>
          Back to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="page-eyebrow">Edit Task</span>
          <h1 className="page-title">{task.title}</h1>
          <p className="page-subtitle">Update the details below and save your changes.</p>
        </div>
      </div>

      <div style={{ maxWidth: "560px" }}>
        <TaskForm
          initialValues={task}
          onSubmit={handleSubmit}
          submitLabel="Save Changes"
          onCancel={() => navigate("/dashboard")}
        />
      </div>
    </div>
  );
};

export default EditTask;
