const express = require("express");
const { body } = require("express-validator");
const { protect } = require("../middleware/auth");
const {
  getTasks,
  getTaskStats,
  getTask,
  createTask,
  updateTask,
  deleteTask,
} = require("../controllers/taskController");

const router = express.Router();

router.use(protect);

const taskValidation = [
  body("title").trim().notEmpty().withMessage("Title is required"),
  body("priority").optional().isIn(["Low", "Medium", "High"]).withMessage("Invalid priority"),
  body("status").optional().isIn(["To Do", "In Progress", "Completed"]).withMessage("Invalid status"),
  body("dueDate").notEmpty().withMessage("Due date is required").isISO8601().withMessage("Invalid due date"),
];

router.get("/", getTasks);
router.get("/stats", getTaskStats);
router.get("/:id", getTask);
router.post("/", taskValidation, createTask);
router.put("/:id", taskValidation, updateTask);
router.delete("/:id", deleteTask);

module.exports = router;
