const express = require("express");
const { body } = require("express-validator");
const { protect } = require("../middleware/auth");
const { getProfile, updateProfile, changePassword } = require("../controllers/userController");

const router = express.Router();

router.use(protect);

router.get("/me", getProfile);

router.put(
  "/me",
  [
    body("name").optional().trim().notEmpty().withMessage("Name cannot be empty"),
    body("bio").optional().isLength({ max: 300 }).withMessage("Bio must be under 300 characters"),
  ],
  updateProfile
);

router.put(
  "/change-password",
  [
    body("currentPassword").notEmpty().withMessage("Current password is required"),
    body("newPassword").isLength({ min: 6 }).withMessage("New password must be at least 6 characters"),
  ],
  changePassword
);

module.exports = router;
