const { validationResult } = require("express-validator");
const Task = require("../models/Task");
const asyncHandler = require("../utils/asyncHandler");

// @desc    List tasks for the logged-in user (search, filter, paginate)
// @route   GET /api/tasks
// @access  Private
const getTasks = asyncHandler(async (req, res) => {
  const { search, status, priority, page = 1, limit = 8, sortBy = "createdAt", order = "desc" } = req.query;

  const query = { user: req.user._id };

  if (search) {
    query.$or = [
      { title: { $regex: search, $options: "i" } },
      { description: { $regex: search, $options: "i" } },
    ];
  }

  if (status && status !== "All") query.status = status;
  if (priority && priority !== "All") query.priority = priority;

  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const limitNum = Math.min(Math.max(parseInt(limit, 10) || 8, 1), 50);
  const skip = (pageNum - 1) * limitNum;

  const sortOptions = { [sortBy]: order === "asc" ? 1 : -1 };

  const [tasks, total] = await Promise.all([
    Task.find(query).sort(sortOptions).skip(skip).limit(limitNum),
    Task.countDocuments(query),
  ]);

  res.status(200).json({
    success: true,
    tasks,
    pagination: {
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.max(Math.ceil(total / limitNum), 1),
    },
  });
});

// @desc    Dashboard statistics for the logged-in user
// @route   GET /api/tasks/stats
// @access  Private
const getTaskStats = asyncHandler(async (req, res) => {
  const userId = req.user._id;

  const [statusCounts, priorityCounts, total, overdue, recent] = await Promise.all([
    Task.aggregate([{ $match: { user: userId } }, { $group: { _id: "$status", count: { $sum: 1 } } }]),
    Task.aggregate([{ $match: { user: userId } }, { $group: { _id: "$priority", count: { $sum: 1 } } }]),
    Task.countDocuments({ user: userId }),
    Task.countDocuments({ user: userId, dueDate: { $lt: new Date() }, status: { $ne: "Completed" } }),
    Task.find({ user: userId }).sort({ updatedAt: -1 }).limit(5),
  ]);

  const toMap = (arr) => arr.reduce((acc, cur) => ({ ...acc, [cur._id]: cur.count }), {});

  res.status(200).json({
    success: true,
    stats: {
      total,
      overdue,
      byStatus: {
        "To Do": 0,
        "In Progress": 0,
        Completed: 0,
        ...toMap(statusCounts),
      },
      byPriority: {
        Low: 0,
        Medium: 0,
        High: 0,
        ...toMap(priorityCounts),
      },
      recentActivity: recent,
    },
  });
});

// @desc    Get a single task
// @route   GET /api/tasks/:id
// @access  Private
const getTask = asyncHandler(async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: "Task not found" });
  }
  res.status(200).json({ success: true, task });
});

// @desc    Create a task
// @route   POST /api/tasks
// @access  Private
const createTask = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg, errors: errors.array() });
  }

  const { title, description, priority, status, dueDate } = req.body;

  const task = await Task.create({
    user: req.user._id,
    title,
    description,
    priority,
    status,
    dueDate,
  });

  res.status(201).json({ success: true, message: "Task created", task });
});

// @desc    Update a task
// @route   PUT /api/tasks/:id
// @access  Private
const updateTask = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg, errors: errors.array() });
  }

  const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: "Task not found" });
  }

  const { title, description, priority, status, dueDate } = req.body;

  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (priority !== undefined) task.priority = priority;
  if (status !== undefined) task.status = status;
  if (dueDate !== undefined) task.dueDate = dueDate;

  await task.save();

  res.status(200).json({ success: true, message: "Task updated", task });
});

// @desc    Delete a task
// @route   DELETE /api/tasks/:id
// @access  Private
const deleteTask = asyncHandler(async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!task) {
    return res.status(404).json({ success: false, message: "Task not found" });
  }
  res.status(200).json({ success: true, message: "Task deleted" });
});

module.exports = { getTasks, getTaskStats, getTask, createTask, updateTask, deleteTask };
