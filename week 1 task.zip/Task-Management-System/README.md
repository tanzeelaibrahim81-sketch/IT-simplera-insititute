# Task Management System

A full-stack **Authentication & Task Management Platform** built for the ITSimplera Fullstack Web Development Internship — Week 1 Task.

Built with the **MERN** stack: MongoDB, Express.js, React.js (Vite), Node.js — with JWT authentication, bcrypt password hashing, and a fully responsive, theme-aware UI.

![Stack](https://img.shields.io/badge/stack-MERN-6C5CE7)
![License](https://img.shields.io/badge/license-MIT-informational)

---

## ✨ Features

### Frontend
- Login, Register, Dashboard, Profile, Create Task, Edit Task pages
- Responsive top navbar + collapsible sidebar
- Dashboard summary cards + statistics chart
- Responsive, sortable, paginated data table
- Dark / Light theme toggle (persisted)
- Global loading indicator + toast notifications
- Client-side form validation with inline errors
- Centralized API error handling
- Mobile-first responsive layout

### Backend
- User registration & login
- Password hashing with bcrypt
- JWT-based authentication + auto logout on token expiry
- Protected routes via middleware
- Full CRUD for tasks (create, read, update, delete)
- Request validation (express-validator)
- Correct HTTP status codes throughout
- Centralized error-handling middleware

### Database (MongoDB)
- `users` collection
- `tasks` collection — each with title, description, priority, status, due date, created date, and owner reference

### Bonus features implemented (8 of 10)
- 🔍 Search tasks by title/description
- 🎛 Filter by status
- 🎛 Filter by priority
- 📄 Pagination
- 👤 Profile update
- 🔑 Password change
- 📊 Dashboard statistics (counts + mini chart)
- ⏱ Auto logout after JWT expiration

---

## 📁 Project Structure

```
Task-Management-System/
│── client/                # React frontend (Vite)
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── context/
│   │   ├── services/
│   │   └── assets/
│   └── package.json
│
│── server/                # Express backend
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── config/
│   ├── utils/
│   └── server.js
│
├── README.md
├── package.json
└── .gitignore
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js (LTS) — https://nodejs.org
- MongoDB Community Server (or a free MongoDB Atlas cluster)
- Git

### 1. Clone & install

```bash
git clone <your-repo-url>
cd Task-Management-System

# install root, server, and client dependencies
npm run install-all
```

### 2. Configure environment variables

Copy the example env file and fill in your own values:

```bash
cd server
cp .env.example .env
```

`.env`:
```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/task-management
JWT_SECRET=replace_this_with_a_long_random_string
JWT_EXPIRES_IN=1h
CLIENT_URL=http://localhost:5173
```

### 3. Run in development

From the project root:

```bash
npm run dev
```

This starts the Express API on `http://localhost:5000` and the React app on `http://localhost:5173` concurrently.

Or run them separately:

```bash
# terminal 1
cd server && npm run dev

# terminal 2
cd client && npm run dev
```

### 4. Build for production

```bash
cd client
npm run build
```

---

## 🔌 API Overview

| Method | Endpoint                     | Description                  | Protected |
|--------|-------------------------------|-------------------------------|-----------|
| POST   | `/api/auth/register`          | Register a new user          | No        |
| POST   | `/api/auth/login`             | Login, returns JWT           | No        |
| GET    | `/api/users/me`               | Get current profile          | Yes       |
| PUT    | `/api/users/me`                | Update profile               | Yes       |
| PUT    | `/api/users/change-password`  | Change password              | Yes       |
| GET    | `/api/tasks`                   | List tasks (search/filter/paginate) | Yes |
| GET    | `/api/tasks/stats`             | Dashboard statistics         | Yes       |
| GET    | `/api/tasks/:id`               | Get single task              | Yes       |
| POST   | `/api/tasks`                   | Create task                  | Yes       |
| PUT    | `/api/tasks/:id`               | Update task                  | Yes       |
| DELETE | `/api/tasks/:id`               | Delete task                  | Yes       |

All protected routes expect `Authorization: Bearer <token>`.

---

## 🛠 Tech Stack

**Frontend:** React 18, React Router 6, Axios, Context API, Recharts, CSS (custom design system)
**Backend:** Node.js, Express.js, express-validator, jsonwebtoken, bcryptjs
**Database:** MongoDB + Mongoose

---

## 📸 Documentation

See `/docs` (create this folder in your submission) for setup screenshots and implementation notes to include in your internship submission write-up.

## 📄 License

MIT — built for educational purposes as part of the ITSimplera internship program.
